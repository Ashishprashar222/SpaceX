from django.shortcuts import render
import requests
from django.core.paginator import EmptyPage, Paginator

def index(request):
    #fetch topo 3 post
    response=requests.get('https://api.spacexdata.com/v3/launches?limit=100').json()
    p=Paginator(response,8)
    page_num = request.GET.get('page',1)
    try:
        page=p.page(page_num)
    except EmptyPage:
        page=p.page(1)

    page=p.page(page_num)
    return render(request,'index.html',{'response':page})



def launch(request):
    response=requests.get('https://api.spacexdata.com/v3/launches?limit=100&amp;launch_success=true').json()
    p=Paginator(response,8)
    page_num = request.GET.get('page',1)
    try:
        page=p.page(page_num)
    except EmptyPage:
        page=p.page(1)

    page=p.page(page_num)
    return render(request,'launch.html',{'response':page})

# Create your views here.
